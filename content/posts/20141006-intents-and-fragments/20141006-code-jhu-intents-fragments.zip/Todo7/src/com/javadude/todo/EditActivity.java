package com.javadude.todo;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.javadude.todo.EditFragment.EditFragmentListener;

public class EditActivity extends ActionBarActivity {
	private EditFragment editFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit);
		
		editFragment = (EditFragment) getSupportFragmentManager()
							.findFragmentById(R.id.editFragment);
		
		editFragment.setEditFragmentListener(new EditFragmentListener() {
			@Override public void onDone(TodoItem item) {
				getIntent().putExtra("todoItemId", item.getId());        /*!!!!!!!!*/
				finish();
			}
			@Override public void onCanceled() {
				finish();
			}
		});
		
		long todoItemId = getIntent().getLongExtra("todoItemId", -1);         /*!!!!!!!!*/
		editFragment.setItemId(todoItemId);
	}
}
