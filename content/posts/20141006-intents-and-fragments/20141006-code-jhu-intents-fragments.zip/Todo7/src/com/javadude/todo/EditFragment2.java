package com.javadude.todo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class EditFragment2 extends Fragment {
	public interface EditFragmentListener2 {
		void onDone(TodoItem item);
		void onCanceled();
	}

	private EditFragmentListener2 editFragmentListener;
	public void setEditFragmentListener(EditFragmentListener2 editFragmentListener) {
		this.editFragmentListener = editFragmentListener;
	}

	private TodoItem item;
	private EditText name;
	private EditText description;
	private EditText priority;
	
	public void setItemId(long todoItemId) {
		if (todoItemId != -1) {
			item = TodoContentProvider.findTodo(getActivity(), todoItemId);            /*!!!!!!!!*/
		} else {
			item = new TodoItem("", "", 1);                                   /*!!!!!!!!*/
		}
			
		name.setText(item.getName());
		description.setText(item.getDisplayName());
		priority.setText(String.valueOf(item.getPriority()));
	}
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_edit2, container, false);
		
		name = (EditText) view.findViewById(R.id.name);
		description = (EditText) view.findViewById(R.id.description);
		priority = (EditText) view.findViewById(R.id.priority);
		
		return view;
	}
	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.edit, menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
			case R.id.action_cancel:
				if (editFragmentListener == null)
					throw new RuntimeException("You need to pass me a listener, fool!");
				editFragmentListener.onCanceled();
				return true;
			case R.id.action_done:
				this.item.setName(name.getText().toString());
				this.item.setDisplayName(description.getText().toString());
				this.item.setPriority(Integer.parseInt(priority.getText().toString()));
				
				TodoContentProvider.updateTodo(getActivity(), this.item);              /*!!!!!!!!*/
				
				if (editFragmentListener == null)
					throw new RuntimeException("You need to pass me a listener, fool!");
				editFragmentListener.onDone(this.item);
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}

}
