package com.javadude.todo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;

import com.javadude.todo.EditFragment.EditFragmentListener;
import com.javadude.todo.EditFragment2.EditFragmentListener2;
import com.javadude.todo.MainFragment.MainFragmentListener;

public class MainActivity extends ActionBarActivity {
	private MainFragment mainFragment;
	private EditFragment editFragment;
	private EditFragment2 editFragment2;
	private boolean useEdit1 = true;

	private void toggleEditFragments(long id) {
		FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
		if (useEdit1) {
			tx.show(editFragment);
			tx.hide(editFragment2);
			editFragment.setItemId(id);
		} else {
			tx.show(editFragment2);
			tx.hide(editFragment);
			editFragment2.setItemId(id);
		}
		tx.commit();
		useEdit1 = !useEdit1;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		mainFragment = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.listFragment);
		editFragment = (EditFragment) getSupportFragmentManager().findFragmentById(R.id.editFragment);
		editFragment2 = (EditFragment2) getSupportFragmentManager().findFragmentById(R.id.editFragment2);
		
		final boolean weHaveMultipleFragments = editFragment != null && editFragment.isInLayout();
		
		if (weHaveMultipleFragments) {
			editFragment.setEditFragmentListener(new EditFragmentListener() {
				@Override public void onDone(TodoItem item) {
					toggleEditFragments(item.getId());
				}
				@Override public void onCanceled() {
				}
			});
			editFragment2.setEditFragmentListener(new EditFragmentListener2() {
				@Override public void onDone(TodoItem item) {
					toggleEditFragments(item.getId());
				}
				@Override public void onCanceled() {
				}
			});
			toggleEditFragments(-1);
		}
		
		mainFragment.setMainFragmentListener(new MainFragmentListener() {
			@Override public void onCreate() {
				if (weHaveMultipleFragments) {
					if (!useEdit1)
						editFragment.setItemId(-1);
					else
						editFragment2.setItemId(-1);
				} else {
					// bring up the edit activity
					Intent intent = new Intent(MainActivity.this, EditActivity.class);
					intent.putExtra("todoItemId", (long) -1);
					startActivity(intent);
				}
			}

			@Override
			public void itemSelected(long id) {
				if (weHaveMultipleFragments) {
					if (!useEdit1)
						editFragment.setItemId(id);
					else
						editFragment2.setItemId(id);
				} else {
					Intent intent = new Intent(MainActivity.this, EditActivity.class);
					intent.putExtra("todoItemId", id);
					startActivity(intent);
				}
			}
		});
	}
}

